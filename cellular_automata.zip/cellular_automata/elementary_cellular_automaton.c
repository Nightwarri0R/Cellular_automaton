#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "elementary_cellular_automaton.h"

void runElementaryCellularAutomaton(int rowSize, int rule[], int noOfGenerations) {

	int row[rowSize];

	for (int i=0; i<rowSize; i++)
		row[i] = 0;

	//Set middle bit of the row to 1
	row[rowSize/2] = 1;

	for (int i = 0; i < noOfGenerations; i++) {
		paintRow(row, rowSize);
		save(row,rowSize);
		calculateNextRow(row, rule, rowSize);
		printf("\n");
	}

	ruleInfomation(rule, rowSize, noOfGenerations);
	saveRuleInfomation(rule, rowSize, noOfGenerations);
	printf("Paterns has been saved to a text file");

}

void paintRow(int row[], int rowSize) {

		
	// prints a white block if the arr contains 1. blank for 0
	for (int i=0; i<rowSize; i++){
		if(row[i] == 1){
			printf("\u2588");
	}else{
			printf(" ");
		}
	}
}

void save(int row[], int rowSize) {
	FILE *f = fopen("cellular.txt", "a");
	FILE *f1 = fopen("cellularNumbers.txt", "a");

	if(f==NULL){
		printf("\n File cannot be opened");
	 	exit(1);
	}
	if(f1==NULL){
		printf("\n File cannot be opened");
	 	exit(1);
	}

	// prints a white block if the arr contains 1. blank for 0
	for (int i=0; i<rowSize; i++){
		if(row[i] == 1) {
			fprintf(f, "\u2588");
			fprintf(f1, "1");
		}else{
			fprintf(f," ");
			fprintf(f1,"0");		
		}
	}
	fprintf(f,"\n");
	fprintf(f1,"\n");
	fclose(f);
	fclose(f1);
}

void calculateNextRow(int currentRow[], int rule[], int rowSize) {
	int nextRow[rowSize];
	// wrap around when the at the 0th position in the nextRow
	nextRow[0] = calculateCell(currentRow[rowSize-1], currentRow[0], currentRow[1], rule);

	for (int i=1; i<(rowSize-1); i++)
		nextRow[i] = calculateCell(currentRow[i-1], currentRow[i], currentRow[i+1], rule);

	// wrap around whan at the i-1 position in the nextRow
	nextRow[rowSize-1] = calculateCell(currentRow[rowSize-2], currentRow[rowSize-1], currentRow[0],rule);

	// copy the memory of nextRow array to the currentRow array using the memcpy function from <string.h> library
	memcpy(currentRow, nextRow, sizeof(nextRow));
}

int calculateCell(int lastRowLeft, int lastRowCentre, int lastRowRight, int rule[]) {
	// eg) lastRowLeft = 1, lastRowCentre = 0, lastRowRight = 1 then if 
	// rule[5] == 1 then 1 is returned else 0 is returned
	if ( rule[(lastRowLeft*4)+(lastRowCentre*2)+(lastRowRight)] == 1 )
		return 1;
	else
		return 0;
}

void saveRuleInfomation(int rule[], int rowSize, int noOfGenerations) {
	FILE *f = fopen("cellular.txt", "a");
	FILE *f1 = fopen("cellularNumbers.txt", "a");

	if(f==NULL){
		printf("\n File cannot be opened");
	 	exit(1);
	}
	if(f1==NULL){
		printf("\n File cannot be opened");
	 	exit(1);
	}

	fprintf(f, "\n                                        ");
	fprintf(f, "\nRule: %d", binaryToDecimal(rule));
	fprintf(f, "\n");
	fprintf(f, "2^n:     1  2  4  8 16 32 64 128");
	fprintf(f, "\n");
	fprintf(f, "Binary: ");
	for (int i = 0; i < 8; i++) {
		fprintf(f, " %d ", *(rule + i));
	}
	fprintf(f, "\nGenerations: %d", noOfGenerations);
	fprintf(f, "\nRow Length: %d", rowSize);
	fprintf(f, "\n_____________________________________________________________________________________________________________________________");
	fprintf(f, "\n");

	fprintf(f1, "Rule: %d", binaryToDecimal(rule));
	fprintf(f1, "\n____________________________________________________________________________________________________________________________");

	fprintf(f,"\n");
	fprintf(f1,"\n");
	fclose(f);
	fclose(f1);
}

void ruleInfomation(int rule[], int rowSize, int noOfGenerations) {
	printf("\n_____________________________________");
	printf("\n                                        ");
	printf("\nRule: %d", binaryToDecimal(rule));
	printf("\n");
	printf("2^n:     1  2  4  8 16 32 64 128");
	printf("\n");
	printf("Binary: ");
	for (int i = 0; i < 8; i++) {
		printf(" %d ", *(rule + i));
	}
	printf("\nGenerations: %d", noOfGenerations);
	printf("\nRow Length: %d", rowSize);
	printf("\n_____________________________________");
	printf("\n");
}

int binaryToDecimal(int rule[]) {
	int decimal = 0;

	// gets the array of binary numbers and converts them into decimal
	// formula -> eg) 01111000 (0 * 2^0) + (1 * 2^1 ) + (1 * 2^2) and so on...
	for (int i = 0; i < 8; i++) {
		decimal += rule[i] * ((int)power(2, i));	
	}

	return decimal;
}

int power(int base, int exponent) {

	int result = 1;

	for (int i=0; i<exponent; i++)
		result = result*base;

	return result;
}