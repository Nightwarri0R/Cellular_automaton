//Cellular automata fun fact: https://en.wikipedia.org/wiki/Cellular_automaton#Biology


//METHODS:

void generateMenu();
void menuDisplay();
int rnd();
int* decimalToBinary(int decimal);
int binaryToDecimal(int rule[]);
int power(int base, int exponent);