

//METHODS:

void runElementaryCellularAutomaton(int rowSize, int rule[], int noOfGenerations);
void paintRow(int row[], int rowSize);
void save(int row[], int rowSize);
void calculateNextRow(int currentRow[], int rule[], int rowSize);
int calculateCell(int lastRowLeft, int lastRowCentre, int lastRowRight, int rule[]);

void saveRuleInfomation(int rule[], int rowSize, int noOfGenerations);
void ruleInfomation(int rule[], int rowSize, int noOfGenerations);

int binaryToDecimal(int rule[]);
int power(int base, int exponent);