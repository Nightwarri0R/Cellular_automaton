//For info and rules on Langton's Ant go to: https://en.wikipedia.org/wiki/Langton's_ant

//Dimensions of grid which the ant traverses
#define GRID_HEIGHT 60
#define GRID_WIDTH 60


//METHODS:

/*
	Method: runLangtonsAnt

	Function: Calls the correct methods at its disposal
			  to produce a Langtons Ant program.

			  For parameters it takes the starting
			  position of the ant on the grid.

			  Dimensions of the grid are set in
			  langtons_ant.h

	Parameters:
		int antX : x position of the ant on the grid
		int anyY : y position of the ant on the grid
*/
int runLangtonsAnt(int _antX, int _antY, char _dir, int iterationsPerSecond, int noOfIterations);

/*
	Method: printGrid

	Function: Print out a 2D array passed
			  as argument to this method
			  in the terminal in the form
			  if a grid of rows and columns

	Parameters:
		char grid[GRID_HEIGHT][GRID_WIDTH] : The grid which the ant traverses
											 initialiazed in runLangtonsAnt()
											 as a 2D array with dimensions
											 defined in the langtons_ant.h
											 as GRID_HEIGHT and GRID_WIDTH
*/
int printGrid(char grid[GRID_HEIGHT][GRID_WIDTH], char antGrid[GRID_HEIGHT][GRID_WIDTH]);

/*
	Method: moveAnt

	Function: Rotate and move the ant according 
			  to original Langton's Ant rules:

			  If ant is standing on marked square -> turn ant 90 degrees left
			  									  -> move ant one square foreward (the way it is facing)

			  If ant is standing on an unmarked square -> turn ant 90 degrees right
			  										   -> move ant one square foreward (the way it is facing)

			  Update the grid that tracks the marked and unmarked squares
			  Update the grid that marks position of the ant

	Parameters:
		char grid[GRID_HEIGHT][GRID_WIDTH] : The grid which the ant traverses
											 initialiazed in runLangtonsAnt()
											 as a 2D array with dimensions
											 defined in the langtons_ant.h
											 as GRID_HEIGHT and GRID_WIDTH
*/
int moveAnt(int *_antX, int *_antY, char *_dir, char grid[GRID_HEIGHT][GRID_WIDTH], char antGrid[GRID_HEIGHT][GRID_WIDTH]);