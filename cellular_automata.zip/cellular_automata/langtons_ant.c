#include <stdio.h>
#include <unistd.h>
#include "errors.h"
#include "langtons_ant.h"

#define clear() printf("\033[H\033[J")

int moveAnt(int *_antX, int *_antY, char *_dir, char grid[GRID_HEIGHT][GRID_WIDTH], char antGrid[GRID_HEIGHT][GRID_WIDTH]) {

	int antX = *_antX;
	int antY = *_antY;
	
	/* Direction which the ant is facing:
	0 : NORTH (UP)
	1 : EAST (RIGHT)
	2 : SOUTH (DOWN)
	3 : WEST (LEFT) */
	char dir = *_dir;

	/* if the position where
	the ant is on the grid is 1
	then turn the ant 90 degrees right

	if the position where
	the ant is on the grid is 0
	then turn the ant 90 degrees left */
	if (grid[antY][antX] == 1) {
		grid[antY][antX] = 0;
		if (dir == 3)
			dir = 0;
		else
			dir++;
	} else {
		grid[antY][antX] = 1;
		if (dir == 0)
			dir = 3;
		else
			dir--;
	}

	/* Set the current postion of the ant
	on the antGrid to 0 before moving the ant */
	antGrid[antY][antX] = 0;

	int maxX = GRID_WIDTH-1;
	int maxY = GRID_WIDTH-1;

	if (dir == 0 /* (UP) */) {
		if (antY == 0)
			antY = maxY;
		else
			antY--;
	} else if (dir == 1 /* (RIGHT) */) {
		if (antX == maxX)
			antX = 0;
		else
			antX++;
	} else if (dir == 2 /* (DOWN) */) {
		if (antY == maxY)
			antY = 0;
		else
			antY++;
	} else /* *dir == 3 (LEFT) */ {
		if (antX == 0)
			antX = maxX;
		else
			antX--;
	}

	/* The ant has been moved, and the new
	position of the ant is marked on the
	ant grid*/
	antGrid[antY][antX] = 1;

	*_antX = antX;
	*_antY = antY;
	*_dir = dir;

	return SUCCESS;

}

int printGrid(char grid[GRID_HEIGHT][GRID_WIDTH], char antGrid[GRID_HEIGHT][GRID_WIDTH]) {

	clear();

	printf("##############################################################\n");

	for (int i=0; i<GRID_HEIGHT; i++) {
		printf("#");
		for (int j=0; j<GRID_WIDTH; j++) {

			if (antGrid[i][j] == 1) {
				printf("A"); // For an actual ant replace 'A' with '\U0001F41C'
			}
			else if (grid[i][j] == 1) {
				printf("\u2588");
			}
			else {
				printf(" ");
			}
		}
		printf("#");
		printf("\n");
	}

	printf("##############################################################\n");

	return SUCCESS;

}

/*
	Method: runLangtonsAnt

	Function: Calls the correct methods at its disposal
			  to produce a Langtons Ant program.

			  For parameters it takes the starting
			  position of the ant on the grid.

			  Dimensions of the grid are set in
			  langtons_ant.h

	Parameters:
		int antX : x position of the ant on the grid
		int anyY : y position of the ant on the grid
*/
int runLangtonsAnt(int _antX, int _antY, char _dir, int iterationsPerSecond, int noOfIterations) {

	int antX = _antX;
	int antY = _antY;
	char dir = _dir;

	if (antX > GRID_WIDTH)
		return ANT_OUT_OF_BOUNDS_X;

	if (antY > GRID_HEIGHT)
		return ANT_OUT_OF_BOUNDS_Y;

	// Initialize Grid
	char grid[GRID_HEIGHT][GRID_WIDTH];
	char antGrid[GRID_HEIGHT][GRID_WIDTH];

	for (int i=0; i<GRID_HEIGHT; i++) {
		for (int j=0; j<GRID_WIDTH; j++) {
			grid[i][j] = 0;
			antGrid[i][j] = 0;
		}
	}

	// Place ant on grid
	antGrid[antY][antX] = 1;

	// Length of pause between each iteration (microseconds)
	int sleepTime = 1000000/iterationsPerSecond;

	// Print initial state of grid
	printGrid(grid, antGrid);

	/* Generate and print iterations for
	number of times specified in noOfIterations
	at time intervals specified in sleepTime*/
	for (int i=1; i<noOfIterations+1; i++) {
		usleep(sleepTime);
		moveAnt(&antX, &antY, &dir, grid, antGrid);
		printGrid(grid, antGrid);
		printf("Time running: Hours: %d   Minutes: %d   Seconds: %d\n", (i/iterationsPerSecond)/1440, ((i/iterationsPerSecond)/60)%60, (i/iterationsPerSecond)%60);
		printf("Iterations Completed: %d\n", i);
	}

	return SUCCESS;
}