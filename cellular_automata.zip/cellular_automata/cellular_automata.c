#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "cellular_automata.h"

//Entry points for the cellular automata this program runs:
void runElementaryCellularAutomaton(int rowSize, int rule[], int noOfGenerations);
int runLangtonsAnt(int _antX, int _antY, char _dir, int iterationsPerSecond, int noOfIterations);
void runConways();

int main() {
	generateMenu();
}

void generateMenu() {
	int decimalInput;
	char choice;
	int *rule;
	int rowSize;
	int noOfIterations;
	int iterationsPerSecond;

	menuDisplay();
	scanf("%c", &choice);
	switch(choice){
		case 'R': 
		case 'r':
			printf("Enter number of iterations you want to generate: \n");
			scanf("%d", &noOfIterations);
			printf("Enter the length of the row to generate: \n");
			scanf("%d", &rowSize);
			rule = decimalToBinary(rnd());
			runElementaryCellularAutomaton(rowSize, rule, noOfIterations);
		break;

		case 'U': 
		case 'u':
			printf("Enter the rule you want to generate: \n");
			scanf("%d", &decimalInput);
			printf("Enter number of iterations you want to generate: \n");
			scanf("%d", &noOfIterations);
			printf("Enter the length of the row to generate: \n");
			scanf("%d", &rowSize);
			rule =decimalToBinary(decimalInput);
			runElementaryCellularAutomaton(rowSize, rule, noOfIterations); 		 		
		break;

		case 'C':
		case 'c':
			runConways();
		break;

		case 'L': 
		case 'l':
			printf("Enter number of iterations you want to generate: \n");
			scanf("%d", &noOfIterations);
			printf("Enter number of iterations you want to generate per second: \n");
			scanf("%d", &iterationsPerSecond);
			printf("\n");
			runLangtonsAnt(30, 30, 0, iterationsPerSecond, noOfIterations);		 		
		break;

		case 'Q':
		case 'q':
			printf("Goodbye ^_^");
			exit(0);
		break;
			default: 
				printf("Please enter valid option!!!");
	}
}

void menuDisplay(){
	printf("\n##################################################");
	printf("\nWelcome to Cellular Automaton");
	printf("\n");
	printf("\nEnter 'R' for Elementrary Cellular Automaton (RANDOM RULE)");
	printf("\nEnter 'U' for Elementrary Cellular Automaton (CHOOSE RULE)");
	printf("\nEnter 'C' for Conways Game of Life");
	printf("\nEnter 'L' for Langtons Ant");
	printf("\n##################################################\n");
}

int rnd() {
	int random;
	int max = 255;
	time_t t;

	// genterates a random number based on the current date and time
	// srand() is used to initialse random number generator
	srand((unsigned) time(&t)); 
	random = rand() % max;

	return random;
}

int* decimalToBinary(int decimal) { 
    // initial array 
    static int binary[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    // length is 8 bits 
    int bit = 0; 

    // while the bit index is in this range
	// formula - > if there is no remainder then 0 would be put into the array.
	// if there is a remainder rhen 1 would be put into the array
    while (bit < 8) {
        int modulus = decimal % 2;
        int quotient = decimal / 2;
        decimal = quotient; 
        binary[bit] = modulus; 
        bit++;
    }
	// returns array address
    return binary;
}