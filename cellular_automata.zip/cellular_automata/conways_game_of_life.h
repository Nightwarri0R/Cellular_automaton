//For info and rules on Conway's Game of Life go to: https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life

#define COLS 100
#define ROWS 100


//METHODS:

int generateNextGen(int** gen);
int** initGen(int row, int col);
void printGen(int** gen);
bool checkNeighbours(int neighbors, int** gen, int row, int col);
void generateConways(int** gen, int max);
int randomiseGen(int** gen); 
void runConways();