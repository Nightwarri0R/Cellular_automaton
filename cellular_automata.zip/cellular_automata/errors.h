//ERROR CODES

	// General:
	#define SUCCESS 0
	#define GENERIC_ERROR 1
	#define NULL_PARAM 2

	// 1D Cellular Automaton:
	
	// Langton's Ant:
	#define ANT_OUT_OF_BOUNDS_X 200 // X position of ant is beyond the width of the grid
	#define ANT_OUT_OF_BOUNDS_Y 201 // Y position of ant is beyond the height of the grid

	// Conway's Game of Life 